public class Main {
    public static void main(String[]args){
        Producto producto1 = new Producto("Laptop",900);
        producto1.mostrar();
        producto1.setPrecio(250);
        producto1.setPrecio(-50);
    }
}