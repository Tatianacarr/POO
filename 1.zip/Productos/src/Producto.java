public class Producto {
    private String nombre;
    private double precio;
    public Producto(String nombre, double precio){
        this.nombre=nombre;
    }
    public void setPrecio(double precio){
        if (precio > 0){
            this.precio = precio;
        }
    }
    public double getPrecio(){
        return precio;
    }
    public void mostrar(){
        System.out.println("Nombre:"+nombre);
        System.out.println("Precio:"+precio);
    }
}
