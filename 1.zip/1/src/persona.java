import java.util.Set;

public class persona {
    private String nombre;
    private int edad;
    public persona(String nombre, int edad){
        this.nombre=nombre;
        setEdad(edad);
    }
    public void setEdad(int edad){
        if (edad >0){
            this.edad=edad;
        }else{
            System.out.println("Edad invalida");
        }
    }
    public int getEdad(){
        return edad;

    }
    public void mostrar(){
        System.out.println("Nombre:"+nombre);
        System.out.println("Edad:"+edad);
    }

}
