public class Main{
    public static void main(String[]args){
        persona persona1= new persona("Angui",22);
        persona1.mostrar();
        persona1.setEdad(-9);
        persona1.getEdad();
        persona1.mostrar();
    }
}
