public class Producto {
    String nombre;
    Double precio;
    int cantidad;

    public Producto(String nombre, Double precio, int cantidad){
        this.nombre=nombre;
        this.precio=precio;
        this.cantidad=cantidad;
    }
    public Producto(){
        this.nombre= "Laptop";
        this.precio= 250.58;
        this.cantidad = 6;
    }
    public Producto(boolean vacio){

    }
    public void mostrarInformacion() {
        System.out.println("Nombre:" +nombre);
        System.out.println("Precio:" +precio);
        System.out.println("Cantidad:"+cantidad);
        System.out.println("///////////////////////");
    }
}
