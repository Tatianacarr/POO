public class Main{
    public static void main(String[]args){
        Producto producto1 = new Producto("Celular",750.68,3);
        Producto producto2 = new Producto();
        Producto producto3 = new Producto(true);
        producto1.mostrarInformacion();
        producto2.mostrarInformacion();
        producto3.mostrarInformacion();
    }
}