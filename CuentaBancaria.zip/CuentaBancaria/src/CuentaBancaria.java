public class CuentaBancaria {
    private String nombreTitular;
    private double saldo;

    public CuentaBancaria(String nombreTitular, double saldo){
        this.nombreTitular=nombreTitular;
        this.saldo=saldo;
    }
    public void mostrar(){
        System.out.println("Ttular:"+nombreTitular);
        System.out.println("Saldo actual:"+saldo);
        System.out.println("****************   ");

    }
    public void depositar(double monto){
        saldo += monto;
        System.out.println("Nuevo deposito:"+monto);
    }
    public void retirar(double monto){
        if (monto <= saldo){
            saldo -=monto;
            System.out.println("Retiro exitoso"+monto);
        }else {
            System.out.println("Fondos insuficientes");

        }
    }
}
