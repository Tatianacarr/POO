public class Main{
    public static void main(String[]args){
        CuentaBancaria cuenta= new CuentaBancaria("Angui",300.00);
        cuenta.mostrar();
        cuenta.depositar(15.35);
        cuenta.mostrar();
        cuenta.retirar(45);
        cuenta.mostrar();

    }
}