public class Libro {
    String titulo;
    String autor;
    int anioPublicacion;
    public Libro(String titulo, String autor, int anioPublicacion){
        this.titulo=titulo;
        this.autor=autor;
        this.anioPublicacion=anioPublicacion;
    }
    public void mostrarInformacion(){
        System.out.println("TITULO:"+titulo);
        System.out.println("AUTOR:"+autor);
        System.out.println("ANIO:"+anioPublicacion);
    }
}
