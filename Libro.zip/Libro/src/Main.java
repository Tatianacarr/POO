public class  Main{
    public static void main(String[]args){
        Libro libro1 = new Libro("100 Anios de soledad","Gabriel Garcia Marquez",1967);
        Libro libro2 = new Libro("Beloved","Toni Morrison",1987);
        libro1.mostrarInformacion();
        libro2.mostrarInformacion();

    }
}